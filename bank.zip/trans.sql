-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2022 at 05:18 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `trans`
--

CREATE TABLE `trans` (
  `Tid` int(11) NOT NULL,
  `acNo` varchar(50) NOT NULL,
  `DT` varchar(50) NOT NULL,
  `Amount` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trans`
--

INSERT INTO `trans` (`Tid`, `acNo`, `DT`, `Amount`, `Description`) VALUES
(1, 'SBI102', 'Thu/Nov/2021  08/21/32', '6000', 'Deposit'),
(2, 'SBI102', 'Thu/Nov/2021  08/23/23', '5000', 'Deposit'),
(3, 'SBI101', 'Thu/Nov/2021  08/23/43', '3000', 'Deposit'),
(4, 'SBI101', 'Thu/Nov/2021  08/23/55', '3000', 'Deposit'),
(5, 'SBI101', 'Thu/Nov/2021  08/24/14', '3000', 'Withdraw'),
(6, 'SBI102', 'Thu/Nov/2021  08/24/59', '3000', 'FundTransfer'),
(7, 'SBI101', 'Thu/Nov/2021  08/24/59', '3000', 'Received'),
(8, 'SBI101', 'Mon/Nov/2021  11/09/14', '2000', 'Withdraw'),
(9, 'SBI101', 'Mon/Nov/2021  11/10/12', '2000', 'Withdraw'),
(10, 'SBI103', 'Sun/Feb/2022  10/37/45', '9000', 'FundTransfer'),
(11, 'SBI105', 'Sun/Feb/2022  10/37/45', '9000', 'Received'),
(12, 'SBI103', 'Sun/Feb/2022  10/40/48', '9000', 'Deposit'),
(13, 'SBI103', 'Sun/Feb/2022  10/43/10', '9000', 'Withdraw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trans`
--
ALTER TABLE `trans`
  ADD PRIMARY KEY (`Tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `trans`
--
ALTER TABLE `trans`
  MODIFY `Tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
