<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<link rel="stylesheet"
   href="effect.css">
<style>
h4
{
	color:darkblue;
	
}
</style>
</head>

<body>
<div class="cont">
<div class="row" style="height:100px; background:skyblue">
<div class="col-md-3"><img src="mybank.jpeg" height="93%" width="100%"></div>
<div class="col-md-6" style="color:darkblue" ><center><h1><b> My Banking App </b></h1></div>
<div class="col-md-3" style='padding-top:15px'>
<br>
<?php
session_start();
	$con=mysqli_connect('localhost','root','')or die("could not connect server".mysqli_error($con));
	mysqli_select_db($con,'mydb')or die("Could not connect database".mysqli_error($con));

if(isset($_SESSION['loguser']))
{
	$ac=$_SESSION['loguser'];
	$q="select * from account where acno='$ac'";
	$rs=mysqli_query($con,$q);
	$r=mysqli_fetch_array($rs);
	echo "<h4 style='margin-left:0px;color:darkblue'> Welcome &nbsp;<strong>$r[2]</strong> &nbsp; <a href='lout.php' style='text-decoration:none;color:darkblue'>Logout</a></h4>";	
}
else
  header('location:login.php');	
?>
</div>
</div>
<div class="row" style="height:35px">
<div class="col-md-12">
<table class="table table-border">

<tr style="background:darkblue">
<th></th><th></th>
<th style="text-decoration:none; color:white; margin-left:20px"> Home </th> 
<th style="text-decoration:none; color:white"> About </th>
<th style="text-decoration:none; color:white"> Contact </th>
<th><a href="ca1.php"  style="text-decoration:none; color:white"> Create Ac</a></th>
<th> <a href="wd.php"  style="text-decoration:none; color:white">Withdraw</a> </th>
<th><a href="dep.php"  style="text-decoration:none; color:white"> Deposit </a> </th>
<th><a href="fn1.php"  style="text-decoration:none; color:white"> Fund Transfer </a> </th>

<th> <a href="bal.php" style="text-decoration:none; color:white"> Balance </a></th>
<th><a href="pass.php" style="text-decoration:none; color:white"> Password change </a></th>
<th><a href="asum.php"  style="text-decoration:none; color:white"> Account summary </a></th>

</tr>
</table>
</div>
</div>
<div class="row" style="height:100px">
<div class="col-md-12">
<h1 style="border:2px solid black"> Account Summary Page</h1></div></div>
<br><br>
<div class="row" style="height:150px">
<div class="col-md-12" style="text-align:center">

</body>
</html>
<?php
/*if(isset($_REQUEST['sub']))
{
	$con=mysqli_connect('localhost','root','')or die("Could not connect server".mysqli_error($con));
	mysqli_select_db($con,'mydb')or die("Could not connect database".mysqli_error($con));
	$ac=$_REQUEST['ac'];
	$pin=$_REQUEST['pin'];
	$q="select * from account where acNo='$ac' && pin='$pin'";
	$rs=mysqli_query($con,$q)or die("Could not execute".mysqli_error($con));
	$x=mysqli_num_rows($rs);
	if($x>0)
	{
		$q="select * from trans where acNo='$ac'";
	$rs1=mysqli_query($con,$q)or die("Could not execute".mysqli_error($con));
	$x=mysqli_num_rows($rs);
	if($x>0)
	{
		echo "<div class='cont'><div class='row'><div class='col-md-3'></div><div class='col-md-6'>";
		echo "<center><table class='table table-bordered'>";
		echo "<tr style='background:darkblue; color:white'><th>Account Number</th><th>Date and Time</th><th>Amount</th><th>Description</th></tr>";
		echo "</table>";
		while($r=mysqli_fetch_array($rs1))
		{
		
		echo "<center><table class='table table-bordered'>";
		echo "<tr style='background:skyblue'><td>$r[1]</td><td>$r[2]</td><td>$r[3]</td><td>$r[4]</td></tr>";
		echo "</table></center>";
		}
		echo "</div></div></div>";
	}
	
	}
	else
		echo"<h2>Invalid Account Number or Pin.</h2>";

}*/

if (isset($_SESSION['loguser']))
{
	$ac=$_SESSION['loguser'];
	$q="select * from trans where acno='$ac'";
	$rs=mysqli_query($con,$q);
	$x=mysqli_num_rows($rs);
	if($x>0)
	{
		echo "<div class='cont'><div class='row'><div class='col-md-3'></div><div class='col-md-6'>";
		echo "<center><table class='table table-bordered'>";
		echo "<tr style='background:darkblue; color:white'><th>Account Number</th><th>Date and Time</th><th>Amount</th><th>Description</th></tr>";
		
		while($r=mysqli_fetch_array($rs))
		{
		
		echo "<tr style='background:skyblue'><td>$r[1]</td><td>$r[2]</td><td>$r[3]</td><td>$r[4]</td></tr>";
		}
		echo "</table></center>";

		echo "</div></div></div>";
	}
	else
echo "<center><h3>No summary available yet. Do some transactions.</h3></center>";	
}
?>