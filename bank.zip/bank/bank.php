<html>
<head>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

</head>
<div class="cont">
<div class="row" style="height:100px; background:skyblue">
<div class="col-md-3"><img src="mybank.jpeg" height="100%" width="100%"></div>
<div class="col-md-6" style="color:darkblue; padding-top:30px; font-family:Cooper" ><center><h1><b> My Banking App </b></h1>
</div>
<div class="col-md-3" style="padding-top:15px">
<br>
<?php
session_start();
	$con=mysqli_connect('localhost','root','')or die("could not connect server".mysqli_error($con));
	mysqli_select_db($con,'mydb')or die("Could not connect database".mysqli_error($con));

if(isset($_SESSION['loguser']))
{
	$ac=$_SESSION['loguser'];
	$q="select * from account where acno='$ac'";
	$rs=mysqli_query($con,$q);
	$r=mysqli_fetch_array($rs);
	echo "<h4 style='margin-left:0px;color:darkblue'> Welcome &nbsp;<strong>$r[2]</strong> &nbsp; <a href='lout.php' style='text-decoration:none;color:darkblue'>Logout</a></h4>";
	
}
else
	echo "&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button class='btn btn-primary'><a href='login.php' style='text-decoration:none;color:white'>Login</a></button>";
	
?>
</div>
</div>
<div class="row" style="height:50px">
<div class="col-md-12">
<table class="table table-border">

<tr style="background:darkblue">
<th></th><th></th>
<th style="text-decoration:none; color:white; margin-left:20px"> Home </th> 
<th style="text-decoration:none; color:white"> About </th>
<th style="text-decoration:none; color:white"> Contact </th>
<th><a href="ca1.php"  style="text-decoration:none; color:white"> Create Ac</a></th>
<th> <a href="wd.php"  style="text-decoration:none; color:white">Withdraw</a> </th>
<th><a href="dep.php"  style="text-decoration:none; color:white"> Deposit </a> </th>
<th><a href="fn1.php"  style="text-decoration:none; color:white"> Fund Transfer </a> </th>

<th> <a href="bal.php" style="text-decoration:none; color:white"> Balance </a></th>
<th><a href="pass.php"  style="text-decoration:none; color:white"> Password change </a></th>
<th><a href="asum.php" style="text-decoration:none; color:white"> Account summary </a></th>

</tr>
</table>
</div>
</div>
<div class="row" style="height:500px">
<div class="col-md-11" style="margin-left:50px">
<div class="row" style="height:250px; padding-top:30px">
<div class="col-md-6"><center> <img src="mb5.jpeg" height="70%" width="70%" style="border-radius:20px"></center></div>
<div class="col-md-6"><center> <img src="img.jpeg" height="70%" width="70%" style="border-radius:20px"></center></div>
</div>
<div class="row" style="height:250px">
<div class="col-md-6"> <center><img src="mb3.jpeg" height="70%" width="70%" style="border-radius:20px"></center></div>
<div class="col-md-6"> <center><img src="mb4.jpeg" height="70%" width="70%" style="border-radius:20px"></center></div>
</div>

</div>
</div>
<div class="row" style="color:darkblue; background:skyblue; height:50px; padding-top:5px">
<div class="col-md-12">
<center><h2 style="font-family:Cooper"><b>Thanks for joining My Banking App</b></h2></center>
</div>
</div>


</div>
</body>
</html>