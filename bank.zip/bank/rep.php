<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<link rel="stylesheet"
   href="effect.css">

</head>

<body>
<center> <h1> Deposit </h1> </center>
<br><br>
<form>
<center>
<table>
<tr> <th> Enter Account No. </th> <td> <input type="text" name="ac"> </td> </tr>
<tr> <th> Enter Pin </th> <th> <input type="text" name="pin"> </td> </tr>
<tr> <th> Amount to Deposit </th> <td> <input type="text" name="am"> </td> </tr>
<tr> <td> <input type="submit" name="sub" value="Report"></td> </tr>
</table>
</center>
</form>
</body>
</html>