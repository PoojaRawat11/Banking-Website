<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<style>

</style>
</head>
<div class="cont">
<div class="row" style="height:100px; background:skyblue">
<div class="col-md-3"><img src="mybank.jpeg" height="100%" width="100%"></div>
<div class="col-md-9" style="color:darkblue; padding-top:30px; font-family:Cooper" ><center><h1><b> My Banking App </b></h1></div>
</div>
<div class="row" style="height:100px">
<div class="col-md-12">

<h1 style="border:2px solid black; background:skyblue; text-align:center; font-family:Cooper"> User LogIn Page </h1></div></div>
<br><br>
<div class="row" style="height:300px">
<div class="col-md-12" style="text-align:center">
<form>
<center>
<table>
<tr> <th> Enter Account No. </th> <td> <input type="text" name="ac"> </td> </tr>
<tr> <th> Enter Pin </th> <th> <input type="text" name="pin"> </td> </tr>
<tr> <td> <input type="submit" name="sub" value="LogIn" class="btn btn-primary"></td> </tr>
</table>
</center>
</form>
</div></div></div>
</body>
</html>
<?php
session_start();
if(isset($_REQUEST['sub']))
{
	$con=mysqli_connect('localhost','root','')or die("Could not connect server".mysqli_error($con));
	mysqli_select_db($con,'mydb')or die("Could not connect database".mysqli_error($con));
	$ac=$_REQUEST['ac'];
	$pin=$_REQUEST['pin'];
	$q="select * from account where acNo='$ac' && pin='$pin'";
	$rs=mysqli_query($con,$q)or die("Could not execute".mysqli_error($con));
	$x=mysqli_num_rows($rs);
	if($x>0)
	{
	session_start();
	$_SESSION['loguser']=$ac;
	header('location:bank.php');
	}		 
	else
		echo "<h2>Invlaid User Name or Pasword</h2>";
}
?>