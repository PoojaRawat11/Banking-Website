<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<link rel="stylesheet"
   href="effect.css">
<style>
h4
{
	color:darkblue;
	
}
</style>
</head>

<body>
<div class="cont">
<div class="row" style="height:100px; background:skyblue">
<div class="col-md-3"><img src="mybank.jpeg" height="93%" width="100%"></div>
<div class="col-md-6" style="color:darkblue" ><center><h1><b> My Banking App </b></h1></div>
<div class="col-md-3"style='padding-top:15px'>
<br>
<?php
session_start();
	$con=mysqli_connect('localhost','root','')or die("could not connect server".mysqli_error($con));
	mysqli_select_db($con,'mydb')or die("Could not connect database".mysqli_error($con));

if(isset($_SESSION['loguser']))
{
	$ac=$_SESSION['loguser'];
	$q="select * from account where acno='$ac'";
	$rs=mysqli_query($con,$q);
	$r=mysqli_fetch_array($rs);
	echo "<h4 style='margin-left:0px;color:darkblue'> Welcome &nbsp;<strong>$r[2]</strong> &nbsp; <a href='lout.php' style='text-decoration:none;color:darkblue'>Logout</a></h4>";
	
}
else
  header('location:login.php');	
?>
</div>
</div>
<div class="row" style="height:35px">
<div class="col-md-12">
<table class="table table-border">

<tr style="background:darkblue">
<th></th><th></th>
<th style="text-decoration:none; color:white; margin-left:20px"> Home </th> 
<th style="text-decoration:none; color:white"> About </th>
<th style="text-decoration:none; color:white"> Contact </th>
<th><a href="ca1.php"  style="text-decoration:none; color:white"> Create Ac</a></th>
<th> <a href="wd.php"  style="text-decoration:none; color:white">Withdraw</a> </th>
<th><a href="dep.php"  style="text-decoration:none; color:white"> Deposit </a> </th>
<th><a href="fn1.php"  style="text-decoration:none; color:white"> Fund Transfer </a> </th>

<th> <a href="bal.php" style="text-decoration:none; color:white"> Balance </a></th>
<th><a href="pass.php" style="text-decoration:none; color:white"> Password change </a></th>
<th><a href="asum.php" style="text-decoration:none; color:white"> Account summary </a></th>

</tr>
</table>
</div>
</div>
<div class="row" style="height:100px">
<div class="col-md-12">
<h1 style="border:2px solid black"> Password Change Page</h1></div></div>
<br><br>
<div class="row" style="height:300px">
<div class="col-md-12" style="text-align:center">
<form>
<center>
<table>

<tr> <th> Enter New Pin </th> <th> <input type="text" name="np"></td> </tr>
<tr> <td> <input type="submit" name="sub" value="Change Password" class="btn btn-primary"></td> </tr>
</table>
</center>
</form>
</div></div></div>
</body>
</html>
<?php
if(isset($_REQUEST['sub']))
{
	
	if(isset($_SESSION['loguser']))
{
	$ac=$_SESSION['loguser'];
	$np=$_REQUEST['np'];
	$q="select * from account where acno='$ac'";
	$rs=mysqli_query($con,$q);
	$r=mysqli_num_rows($rs);
	if($r>0)
	{
		$q="update account set Pin='$np' where acNo='$ac' ";
		mysqli_query($con,$q);
		echo "<h2>Pin updated Successfully</h2>";
	}
	else
		header('location:login.php');
}
}
?>