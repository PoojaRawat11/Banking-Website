<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

<link rel="stylesheet"
 href="effect.css">
</head>
<body>
<div class="cont">
<div class="row" style="height:100px; background:skyblue">
<div class="col-md-3"><img src="mybank.jpeg" height="93%" width="100%"></div>
<div class="col-md-9" style="color:darkblue" ><center><h1><b> My Banking App </b></h1></div>

</div>
<div class="row" style="height:35px">
<div class="col-md-12">
<table class="table table-border">

<tr style="background:darkblue">
<th></th><th></th>
<th style="text-decoration:none; color:white; margin-left:20px"> Home </th> 
<th style="text-decoration:none; color:white"> About </th>
<th style="text-decoration:none; color:white"> Contact </th>
<th><a href="ca1.php"  style="text-decoration:none; color:white"> Create Ac</a></th>
<th> <a href="wd.php"  style="text-decoration:none; color:white">Withdraw</a> </th>
<th><a href="dep.php"  style="text-decoration:none; color:white"> Deposit </a> </th>
<th><a href="fn1.php"  style="text-decoration:none; color:white"> Fund Transfer </a> </th>

<th> <a href="bal.php" style="text-decoration:none; color:white"> Balance </a></th>
<th><a href="pass.php"  style="text-decoration:none; color:white"> Password change </a></th>
<th><a href="asum.php"  style="text-decoration:none; color:white"> Account summary </a></th>

</tr>
</table>
</div>
</div>
<div class="row" style="height:100px">
<div class="col-md-12">
<h1 style="border:2px solid black"> Create Account Page </h1></div></div>
<br><br>
<div class="row" style="height:300px">
<div class="col-md-12" style="text-align:center">
<form>
<center>
<table>
<tr><th> Enter Pin </th> <td><input type="text" name="p"></td></tr>
<tr><th>Enter Name </th> <td><input type="text" name="n"></td></tr>
<tr><th>Enter Father's Name</th><td><input type="text" name="fn"></td></tr>
<tr><th>Enter Email</th><td><input type="text" name="em"></td></tr>
<tr><th>Enter Phone No.</th><td><input type="text" name="ph"></td></tr>
<tr><th>Enter Gender</th><td> <input type="radio" name="gen" value="male">Male
<input type="radio" name="gen" value="Female">Female</td></tr>

<tr><th>Enter Country</th>
<td><select name="cn">
<option>--SelectCountry--</option>
<option value="Afganistan"> Afganistan </option>
<option value="Bhutaan"> Bhutaan </option>
<option value="China"> China </option>
<option value="France"> France </option>
<option value="Germon"> Germon </option>
<option value="india"> India </option>
<option value="Japan"> Japan </option>
</select>
</td></tr>

<tr><th>Enter State</th>
<td><select name="st">
<option>--SelectState--</option>
<option value="Assam"> Assam </option>
<option value="Bihar"> Bihar </option>
<option value="Goa"> Goa </option>
<option value="Uttar Pradesh"> Uttar Pradesh </option>
<option value="Uttarakhand"> Uttarakhand </option>
<option value="West Bengal"> West Bengal </option>
<option value="Tripura"> Tripura </option>
</select>

</td>
</tr>

<tr><th>Enter City </th>
<td><select name="ct">
<option>--SelectCity--</option>
<option value="Almora"> Almora </option>
<option value="Dehradun"> Dehradun </option>
<option value="Chamoli"> Chamoli </option>
<option value="Pithoragarh"> Pithoragarh </option>
<option value="Nainital"> Nainital </option>
<option value="Pauri"> Pauri </option>
<option value="Rudraprayag"> Rudraprayag </option>
</select>
</td>
</tr>
<tr><th>Enter Amount</th>
<td><input type="text" name="am"></td></tr>
<tr><td><input type="submit" name="sub" value="Submit" class="btn btn-primary"></td></tr>
</table>
</center>
</form>
</div>
</div>
</div>
</body>
</html>
<?php
if(isset($_REQUEST['sub']))
{
	$con=mysqli_connect('localhost','root','')or die("Could not connect server".mysqli_error($con));
mysqli_select_db($con,'mydb')or die("Could not connect db".mysqli_error($con));

$p=$_REQUEST['p'];
$n=$_REQUEST['n'];
$fn=$_REQUEST['fn'];
$em=$_REQUEST['em'];
$ph=$_REQUEST['ph'];
$gen=$_REQUEST['gen'];
$cn=$_REQUEST['cn'];
$st=$_REQUEST['st'];
$ct=$_REQUEST['ct'];
$am=$_REQUEST['am'];
$ac="SBI";
$q="select * from account";
$rs=mysqli_query($con,$q);
$x=mysqli_num_rows($rs);   
if($x>0)
{
$x++;
$x=$x+100;
$ac=$ac.$x;
}
else
$ac="SBI101";
/*echo "<br><h2>Account number is = $ac</h2>";*/
$q="insert into account values('$ac','$p','$n','$fn','$em','$ph','$gen','$cn','$st','$ct','$am')";
mysqli_query($con,$q)or die("could not execute".mysqli_error($con));
echo "<br><h2> Account has been created with Account Number=$ac</h2>";
}
?>