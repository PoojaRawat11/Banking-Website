-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2022 at 05:18 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `acNo` varchar(50) NOT NULL,
  `Pin` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Country` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`acNo`, `Pin`, `Name`, `fName`, `Email`, `Phone`, `Gender`, `Country`, `State`, `City`, `amount`) VALUES
('SBI101', '248111', 'Pooja', 'Mr.Harish Singh Rawat', 'p@gamil.com', '7017554700', 'Female', 'india', 'Uttarakhand', 'Dehradun', '14000'),
('SBI102', '248121', 'Saurabh', 'MR.', 's@gmail.com', '98987989', 'Male', 'india', 'Uttarakhand', 'Dehradun', '12000'),
('SBI103', '248111', 'Yasmeen ', 'Mr.', 'y@gmail.com', '1234567', 'Female', 'india', 'Uttarakhand', 'Dehradun', '10000'),
('SBI104', '248111', 'Mohit Singh', 'Mr.Harish Singh Rawat', 'm@gmail.com', '678733949', 'Male', 'india', 'Uttarakhand', 'Pauri', '30000'),
('SBI105', '248111', 'Rohit', 'MR.', 'r@gmail', '1234567', 'Male', 'india', 'Uttarakhand', 'Dehradun', '19000'),
('SBI106', '248111', 'Vaishnavi', 'MR.', 'v@gmail.com', '1234567', 'Female', 'india', 'Uttarakhand', 'Dehradun', '15000'),
('SBI107', '12345', 'Kavya', 'Mr. Dharam Singh', 'k@123', '56879910', 'Female', 'india', 'Uttarakhand', 'Dehradun', '10000'),
('SBI108', '241111', 'Pooja Rawat', 'Mr. Harish Singh Rawat', 'p11@gmail.com', '12121212', 'Female', 'india', 'Uttarakhand', 'Dehradun', '20000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`acNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
